
function [forecast,guess]=weather(ws,wd,mr,si,se,cdc)
%*****************************************************************************************
Author_Intro=struct('Name','Worldhitter','Rno','2001-mct-685','Oranization','U.E.T','Email','worldhitter@hotmail.com')
%*****************************************************************************************
%following are the codes 
%wd=Wind Direction
%ws=Wind Speed
%mr=Moisture ratio(Percentage)
%si=Sunlight Intensity(Percentage)
%se=Season
%cdc=Clouds color
%in order to start the programm enter  all the inputs as logic 1
%*****************************************************************************************
wd=menu('Choose the wind direction','East','West','North','South','North East','Noth West','South East','South West');
type=['East','West','North','South','North East','Noth West','South East','South West'];
%*****************************************************************************************
ws=menu('Choose the wind speed','70km/h','80km/h','90km/h','100km/h','110km/h','125km/h','140km/h','170km/h');
type=['70km/h','80km/h','90km/h','100km/h','110km/h','125km/h','140km/h','170km/h'];
%******************************************************************************************
mr=menu('Choose the moisture ratio ','30%','40%','50%','60%','70%','80%','90%','100');
type=['30%','40%','50%','60%','70%','80%','90%','100'];
%******************************************************************************************
si=menu('Choose sunlight intensity)','0%','20%','40%','50%','60%','70%','80%','100%');
type=['0%','20%','40%','50%','60%','70%','80%','100%'];
%*****************************************************************************************
se=menu('Choose the season','Winter','Summer','Spring','Autumn');
type=['Winter','Summer','Spring','Autumn'];
%*****************************************************************************************
cdc=menu('Choose the color of clouds','Grey','White','Black','Greenish grey','Clear Sky');
type=['Grey','White','Black','Greenish grey','Clear Sky'];
%*****************************************************************************************
  if( (wd == 1) | (ws==1) | (mr == 1) | (si == 2)  |  (se == 1)  | (cdc == 2))
   forecast='The weather will remain pleasent for next 2 days sky will be clear afterein'
   guess='The temperature ranges from 15 to 20 degrees centigrade'
  elseif((wd == 1) | (ws == 2) | (mr == 1) | (si == 4)  |  (se == 1)  | (cdc == 2))
      forecast='The weather will pleasent throughout the day'
      guess='The temperature ranges from 13 to 17 degrees celciuus'
  elseif((wd == 1) | (ws == 2) | (mr == 1) | (si == 4)  |  (se == 1)  | (cdc == 2))
      forecast='The weather will pleasent throughout the day'
      guess='The temperature ranges from 13 to 17 degrees celciuus'        
  elseif((wd == 1) | (ws == 3) | (mr == 2) | (si == 4)  |  (se == 1)  | (cdc == 2))
      forecast='There might be light shower after noon '
      guess='The temperature ranges from 7 to 14 degrees celciuus'        
  elseif((wd == 1) | (ws == 2) | (mr == 1) | (si == 4)  |  (se == 1)  | (cdc == 2))
      forecast='The weather will pleasent throughout the day'
      guess='The temperature ranges from 13 to 17 degrees celciuus'        
  elseif((wd == 8) | (ws == 5) | (mr == 5) | (si ==1)  |  (se == 2)  | (cdc == 3))
      forecast='Thunder storm and heavy showers are expected'        
  elseif((wd == 3) | (ws == 2) | (mr == 2) | (si == 2)  |  (se == 3)  | (cdc == 4))
      forecast='This is an indication of svere storm'
      guess='The temperature ranges from 20 to 30 degrees celcius'      
  elseif((wd == 4) | (ws == 1) | (mr == 3) | (si == 6)  |  (se == 2)  | (cdc == 5))
      forecast='The weather will remain hot for a week'
      guess='The temperature ranges from 38 to 49 degrees celcius'            
  elseif((wd == 4) | (ws == 4) | (mr == 7) | (si == 4)  |  (se == 2)  | (cdc == 2))
      forecast='These  are clear indication of rain after one day'
      guess='The temperature ranges from 30 to 41 degrees celcius'            
  elseif((wd == 7) | (ws == 7) | (mr == 8) | (si == 1)  |  (se == 2)  | (cdc == 4))
      forecast='Cruel clouds may distroy the crops, they  can be activated at any time'
      guess='The temperature ranges from 15 to 34 degrees celcius'           
  elseif((wd == 3) | (ws == 5) | (mr == 6) | (si == 4)  |  (se == 3)  | (cdc == 5))
      forecast='This is beautiful weather it will be maintained for 2 to 3 days'
      guess='The temperature ranges from 23 to 28 degrees celcius'            
  elseif((wd == 6) | (ws == 3) | (mr == 7) | (si == 5)  |  (se == 2)  | (cdc == 2))
      forecast='Hot moisty air will blow all the day'
      guess='The temperature ranges from 31 to 44 degrees celcius'      
  elseif((wd == 5) | (ws == 6) | (mr == 5) | (si == 8)  |  (se == 2)  | (cdc == 5))
      forecast='Hot air will blow for two days'
      guess='The temperature ranges from 35 to 54 degrees celcius'      
  elseif((wd == 8) | (ws == 8) | (mr == 4) | (si == 5)  |  (se == 2)  | (cdc == 1))
      forecast='Hot moisty air will blow all the day'
      guess='The temperature ranges from 31 to 44 degrees celcius'      
  elseif((wd == 2) | (ws == 3) | (mr == 4) | (si == 6)  |  (se == 4)  | (cdc == 3))
      forecast='Smooth weather will be through out the day'
      guess='The temperature ranges from 26 to 37 degrees celcius'      
  else forecast='Weather will be all right soon '
      guess='Temperature will be in the normal range today'
end

%******************************************************************************************
if (wd == 8)
    forecast='Be careful! there may be a rain session for a day after 30 hours'
    guess='The temperature will   be in the range of 12 to 34 degrees celcius'
end
if ((si == 2) | (se ==  1))
    forecast='OOps! too cold ,save your self by wearing ,of something wool'
    guess ='The temperature ranges from 1 to 12 degrees celcius'
end
    
    
